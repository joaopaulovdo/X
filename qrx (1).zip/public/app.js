const SUPABASE_URL = 'https://yzpylhczseindmvmqyrq.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_MJqvwv52E_E3GyoxmycVCw_6SVvi3YJ';

// Initialize Supabase Client
try {
    if (!window.supabase) {
        console.error("Supabase library not loaded!");
        alert("Erro ao carregar a biblioteca do banco de dados. Verifique sua conexão ou desative bloqueadores de anúncios.");
    } else {
        window.supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
        
        // Auth state observer
        window.supabaseClient.auth.onAuthStateChange((event, session) => {
            if (event === 'SIGNED_OUT') {
                if (!window.location.pathname.includes('index.html') && window.location.pathname !== '/' && !window.location.pathname.includes('ativar')) {
                    window.location.href = '/index.html';
                }
            }
        });
    }
} catch (e) {
    console.error("Error initializing Supabase:", e);
}

async function getCurrentUser() {
    try {
        if (!window.supabaseClient) {
            console.error("Supabase client not initialized");
            return null;
        }
        const { data: { session }, error: sessionError } = await window.supabaseClient.auth.getSession();
        if (sessionError || !session) return null;
        
        const { data: profile, error: profileError } = await window.supabaseClient
            .from('profiles')
            .select('*')
            .eq('id', session.user.id)
            .single();
            
        return { ...session.user, profile: profile || {} };
    } catch (err) {
        console.error("Error getting user:", err);
        return null;
    }
}

async function logout() {
    try {
        if (window.supabaseClient) {
            await window.supabaseClient.auth.signOut();
        }
    } catch (e) {
        console.error("Error during sign out:", e);
    }
    // Force clear local storage to ensure session is destroyed locally
    localStorage.clear();
    sessionStorage.clear();
    window.location.href = '/index.html';
}

// Custom Modal System
window.qrx = {
    modal: {
        confirm: (title, message, onConfirm) => {
            const modalHtml = `
                <div id="qrx-modal" class="fixed inset-0 bg-black/80 backdrop-blur-sm z-[100] flex items-center justify-center p-4 animate-in fade-in duration-200">
                    <div class="bg-[#1E293B] border border-slate-700 rounded-2xl w-full max-w-sm overflow-hidden shadow-2xl scale-in-center">
                        <div class="p-6 text-center">
                            <div class="w-16 h-16 bg-red-500/10 text-red-500 rounded-full flex items-center justify-center mx-auto mb-4">
                                <i class="ph ph-warning text-3xl"></i>
                            </div>
                            <h3 class="text-xl font-bold text-white mb-2">${title}</h3>
                            <p class="text-slate-400 text-sm">${message}</p>
                        </div>
                        <div class="flex border-t border-slate-700">
                            <button id="qrx-modal-cancel" class="flex-1 py-4 text-slate-400 hover:text-white font-medium transition hover:bg-slate-800/50">Cancelar</button>
                            <button id="qrx-modal-confirm" class="flex-1 py-4 text-red-500 hover:bg-red-500/10 font-bold transition border-l border-slate-700">Excluir</button>
                        </div>
                    </div>
                </div>
            `;
            document.body.insertAdjacentHTML('beforeend', modalHtml);
            
            const modal = document.getElementById('qrx-modal');
            const cancelBtn = document.getElementById('qrx-modal-cancel');
            const confirmBtn = document.getElementById('qrx-modal-confirm');
            
            const close = () => {
                modal.classList.add('animate-out', 'fade-out');
                setTimeout(() => modal.remove(), 200);
            };
            
            cancelBtn.onclick = close;
            confirmBtn.onclick = () => {
                onConfirm();
                close();
            };
        },
        alert: (title, message, type = 'info') => {
            const icon = type === 'success' ? 'ph-check-circle' : (type === 'error' ? 'ph-x-circle' : 'ph-info');
            const iconColor = type === 'success' ? 'text-green-500' : (type === 'error' ? 'text-red-500' : 'text-[#F97316]');
            const bgColor = type === 'success' ? 'bg-green-500/10' : (type === 'error' ? 'bg-red-500/10' : 'bg-[#F97316]/10');
            
            const modalHtml = `
                <div id="qrx-alert" class="fixed inset-0 bg-black/80 backdrop-blur-sm z-[100] flex items-center justify-center p-4 animate-in fade-in duration-200">
                    <div class="bg-[#1E293B] border border-slate-700 rounded-2xl w-full max-w-sm overflow-hidden shadow-2xl scale-in-center">
                        <div class="p-6 text-center">
                            <div class="w-16 h-16 ${bgColor} ${iconColor} rounded-full flex items-center justify-center mx-auto mb-4">
                                <i class="ph ${icon} text-3xl"></i>
                            </div>
                            <h3 class="text-xl font-bold text-white mb-2">${title}</h3>
                            <p class="text-slate-400 text-sm">${message}</p>
                        </div>
                        <div class="p-4 border-t border-slate-700">
                            <button id="qrx-alert-close" class="w-full py-3 bg-slate-800 hover:bg-slate-700 text-white rounded-lg font-medium transition">OK</button>
                        </div>
                    </div>
                </div>
            `;
            document.body.insertAdjacentHTML('beforeend', modalHtml);
            
            const modal = document.getElementById('qrx-alert');
            const closeBtn = document.getElementById('qrx-alert-close');
            
            closeBtn.onclick = () => {
                modal.classList.add('animate-out', 'fade-out');
                setTimeout(() => modal.remove(), 200);
            };
        }
    }
};
